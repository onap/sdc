heat stack-create vMME -e vmme_small.env -f vmme_small.yml

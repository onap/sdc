#!/bin/bash
# Input: expected input parameter of "environment" to be either of dev, dit, ete, or prd
## env specific config info
dev_nameserver="135.25.120.104"
dev_chef_dns="chef.dev.vcdn.att.net"
dev_static_route="135.182.135.0/24 via 135.182.134.1 dev eth0"
dit_nameserver="135.25.120.104"
dit_chef_dns="chef.dit.vcdn.att.net"
dit_static_route="199.37.175.0/24 via 135.182.135.1 dev eth0"
ete_nameserver="135.25.130.104"
ete_chef_dns="chef.ete.vcdn.att.net"
ete_static_route="199.37.175.0/24 via 135.182.136.1 dev eth0"
prd_nameserver="135.25.140.104"
prd_chef_dns="chef.vcdn.att.net"
prd_static_route="199.37.175.0/24 via 135.182.137.1 dev eth0"
## main()
if [ "$environment" != "dev" -a "$environment" != "dit" -a "$environment" != "ete" -a "$environment" != "prd" ]
then
  echo "Input of \"$environment\" is not a valud enviroment specs among <dev|dit|ete|prd>!" >> /var/tmp/build-type.txt
  exit 1
else
  echo "this is a \"$environment\" build" >> /var/tmp/build-type.txt
  DEST_NAMESERVER="${$environment_nameserver}"
  DEST_CHEF_DNS="${$environment_chef_dns}"
  DEST_STATIC_ROUTE="${$environment_static_route}"
  # Setup /etc/resolv.conf to use environment specific DNS resolver for DNS lookup
  echo "nameserver $DEST_NAMESERVER" > /etc/resolv.conf
  # install chef client from environment specific Chef repository to allow Chef takeover
  echo "[vcdn_repo]
  name=vCDN apps and OS patches
  baseurl=https://$DEST_CHEF_DNS:8090/redhat/6.6
  enabled=1
  gpgcheck=0
  metadata_expire=300
  sslcacert=/etc/chef/trusted_certs/$DEST_CHEF_DNS.crt
  sslverify=false
  " > /etc/yum.repos.d/vcdn.repo
  yum install -y chef.x86_64
  # setup Linux adv routing to allow incoming user login via OAM NIC
  OAM_NIC_IP=$(ip a s dev eth0 primary | grep inet | grep -o '\([0-9]\{1,3\}.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\)'|head -1)
  OAM_GW_IP=$(ip r | grep default | grep eth0 | grep -o '\([0-9]\{1,3\}.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\)')
  echo "
  grep \"2 oam\" /etc/iproute2/rt_tables > /dev/null
  if [ \"\$?\" != 0 ]
  then
    echo \"2 oam\" >> /etc/iproute2/rt_tables
  fi
  ip route add default via $OAM_GW_IP dev eth0 table oam
  ip rule add from $OAM_NIC_IP lookup oam prio 1000
  " >> /etc/rc.d/rc.local
  /bin/bash /etc/rc.d/rc.local
  # Setup static route to consider environment specific NW routing for outgoing OAM connections
  echo -e "\nsetting up static route"
  echo "$DEST_STATIC_ROUTE" > /etc/sysconfig/network-scripts/route-eth0
fi
heat stack-create GWAF -e gwaf_servers.env -f gwaf_servers.yml

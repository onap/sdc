NL="neutron_net_list"
neutron net-list > $NL
#Setting up the LB network from LB1-TO-GWAF.
#GWAF env will be modified
VAL=`cat $NL | grep -i int_ota_fromexternal_gwaf | awk 'NR==1{print $2}'`
echo gwaf_data_network_name UUID is  $VAL;
sed -i  "/int_ota_fromexternal_gwaf_network:/c\  int_ota_fromexternal_gwaf_network:  `echo $VAL`" si-haproxy1.env


VAL=`cat $NL | grep -i int_ota_gwaf_app1_network | awk 'NR==1{print $2}'`
echo int_ota_gwaf_app1_network UUID is  $VAL;
sed -i  "/int_ota_gwaf_app1_network:/c\  int_ota_gwaf_app1_network:  `echo $VAL`" si-haproxy2.env

VAL=`cat $NL | grep -i int_ota_app1_gwaf_network | awk 'NR==1{print $2}'`
echo int_ota_app1_gwaf_network  $VAL;
sed -i  "/int_ota_app1_gwaf_network:/c\  int_ota_app1_gwaf_network:  `echo $VAL`" si-haproxy2.env

VAL=`cat $NL | grep -i int_ota_app1_kms | awk 'NR==1{print $2}'`
echo int_ota_app1_kms is  $VAL;
sed -i  "/int_ota_app1_kms:/c\  int_ota_app1_kms:  `echo $VAL`" si-haproxy3.env

VAL=`cat $NL | grep -i int_ota_kms_app1 | awk 'NR==1{print $2}'`
echo int_ota_kms_app1  UUID is  $VAL;
sed -i "/int_ota_kms_app1:/c\  int_ota_kms_app1:  `echo $VAL`" si-haproxy3.env


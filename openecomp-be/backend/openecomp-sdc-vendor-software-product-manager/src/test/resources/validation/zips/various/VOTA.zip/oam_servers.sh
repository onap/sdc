heat stack-create OAM -e oam_servers.env -f oam_servers.yml


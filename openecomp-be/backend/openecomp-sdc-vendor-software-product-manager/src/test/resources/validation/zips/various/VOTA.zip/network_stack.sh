heat stack-create NETWORK -e network_stack.env -f network_stack.yml

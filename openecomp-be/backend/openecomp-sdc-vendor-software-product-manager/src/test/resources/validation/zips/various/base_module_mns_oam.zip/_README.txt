Sequence of Stack Creation


OAM:

infra.00.mns_np_oam_1
infra.01.mns_vn_oam_mgmt_net_1
infra.02.mns_vn_oam_protected_net_1
infra.03.mns_vn_oam_direct_net_1
infra.04.mns_vn_oam_hsl_net_1
infra.mns_vf_zrdm3frwl01_1
base_mns_zrdm3frwl01oam_00_stsi_1
module_mns_zrdm3frwl01oam_01_rgvm_1 (x's 2 for 2 4-VM Stacks w/ different AvailabilityZones)


DMZ:

infra.00.mns_np_dmz_1
[>> already created: infra.02.mns_vn_oam_protected_net_1 ]
infra.02.mns_vn_dmz_protected_net_1
infra.03.mns_vn_dmz_direct_net_1
infra.04.mns_vn_dmz_hsl_net_1
[>> already created: infra.mns_vf_zrdm3frwl01_1 ]
base_mns_zrdm3frwl01dmz_00_stsi_1
module_mns_zrdm3frwl01dmz_01_rgvm_1 (x's 2 for 2 4-VM Stacks w/ different AvailabilityZones)

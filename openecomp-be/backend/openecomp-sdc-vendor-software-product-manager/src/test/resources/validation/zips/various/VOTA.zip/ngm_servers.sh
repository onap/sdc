heat stack-create NGM -e ngm_servers.env -f ngm_servers.yml

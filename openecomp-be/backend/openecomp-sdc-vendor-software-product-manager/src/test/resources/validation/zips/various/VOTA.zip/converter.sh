heat stack-create Converter -e converter.env -f converter.yml

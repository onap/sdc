README:

This TOSCA profile is a mock VF resource of ASDC.